const _0x1d6e98=_0x1eb6;(function(_0xf9a2e0,_0x2faecd){const _0x43dd89=_0x1eb6,_0x293e23=_0xf9a2e0();while(!![]){try{const _0x1f628e=parseInt(_0x43dd89(0xa5))/0x1*(parseInt(_0x43dd89(0x90))/0x2)+-parseInt(_0x43dd89(0x9b))/0x3*(parseInt(_0x43dd89(0xa7))/0x4)+-parseInt(_0x43dd89(0x6c))/0x5+-parseInt(_0x43dd89(0x6d))/0x6+parseInt(_0x43dd89(0x77))/0x7*(-parseInt(_0x43dd89(0x71))/0x8)+-parseInt(_0x43dd89(0x89))/0x9+-parseInt(_0x43dd89(0xaf))/0xa*(-parseInt(_0x43dd89(0xa4))/0xb);if(_0x1f628e===_0x2faecd)break;else _0x293e23['push'](_0x293e23['shift']());}catch(_0x487988){_0x293e23['push'](_0x293e23['shift']());}}}(_0x153d,0xd2014));const {mediafireDl}=require(_0x1d6e98(0xaa)),{adams}=require('../Ibrahim/adams'),getFBInfo=require('@xaviabot/fb-downloader');function _0x1eb6(_0x1865c9,_0x17b9e5){const _0x153d53=_0x153d();return _0x1eb6=function(_0x1eb6fe,_0x491f5b){_0x1eb6fe=_0x1eb6fe-0x66;let _0xaa2fe1=_0x153d53[_0x1eb6fe];return _0xaa2fe1;},_0x1eb6(_0x1865c9,_0x17b9e5);}adams({'nomCom':_0x1d6e98(0x68),'categorie':_0x1d6e98(0xae)},async(_0x443624,_0x3293a5,_0x51afbf)=>{const _0x3a3bea=_0x1d6e98,{ms:_0x435786,repondre:_0x4dbe98,arg:_0x7a859c}=_0x51afbf,_0x57335b=_0x7a859c[_0x3a3bea(0x92)]('\x20');if(!_0x57335b)return _0x4dbe98(_0x3a3bea(0xa6));if(!_0x57335b['includes']('github.com'))return _0x4dbe98(_0x3a3bea(0x9a));let [,_0xf8e241,_0x3b19fc]=_0x57335b['match'](/(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i)||[];_0x3b19fc=_0x3b19fc[_0x3a3bea(0x6f)](/.git$/,'');let _0x68e95=_0x3a3bea(0x84)+_0xf8e241+'/'+_0x3b19fc+'/zipball',_0x43b2a0=(await fetch(_0x68e95,{'method':_0x3a3bea(0xab)}))[_0x3a3bea(0x8e)]['get'](_0x3a3bea(0x94))[_0x3a3bea(0x97)](/attachment; filename=(.*)/)[0x1];_0x3293a5[_0x3a3bea(0x9c)](_0x443624,{'document':{'url':_0x68e95},'fileName':_0x43b2a0+_0x3a3bea(0x88),'mimetype':_0x3a3bea(0xa8)},{'quoted':_0x435786})[_0x3a3bea(0xa2)](_0x445e50=>_0x4dbe98('error'));}),adams({'nomCom':'tiktok','categorie':'Download'},async(_0x5d38de,_0x45ab7f,_0x11aebd)=>{const _0x574c55=_0x1d6e98,{ms:_0x73cd0c,repondre:_0x107b4c,arg:_0x19fa20}=_0x11aebd;let _0x71d1a2=_0x19fa20[_0x574c55(0x92)]('\x20');if(!_0x19fa20[0x0])return _0x107b4c(_0x574c55(0xa1));const _0x241546=await fetch(_0x574c55(0x8a)+_0x71d1a2),_0x257104=await _0x241546[_0x574c55(0x6e)]();await _0x107b4c('A\x20moment,\x20*BMW-MD*\x20is\x20Downloading\x20that...');const _0x30920c=_0x257104['data'][_0x574c55(0x87)];await _0x45ab7f['sendMessage'](_0x5d38de,{'video':{'url':_0x30920c},'caption':'_╰►VIDEO\x20DOWNLOADED\x20BY_\x20*BMW-MD*','gifPlayback':![]},{'quoted':_0x73cd0c});}),adams({'nomCom':_0x1d6e98(0x76),'categorie':_0x1d6e98(0xae)},async(_0x1c430f,_0x46a8e6,_0x102136)=>{const _0x29d5c5=_0x1d6e98,{ms:_0x4e1dcb,repondre:_0x1ced16,arg:_0xd2394d}=_0x102136;let _0x2ceba5=_0xd2394d[_0x29d5c5(0x92)]('\x20');if(!_0xd2394d[0x0]){_0x1ced16(_0x29d5c5(0x9f));return;}try{const _0x1481aa=await fetch(_0x29d5c5(0x8d)+_0x2ceba5),_0x15ff56=await _0x1481aa[_0x29d5c5(0x6e)](),_0x58f630=_0x15ff56[_0x29d5c5(0x7d)];_0x46a8e6[_0x29d5c5(0x9c)](_0x1c430f,{'image':{'url':_0x58f630},'caption':_0x29d5c5(0x66),'gifPlayback':![]},{'quoted':_0x4e1dcb});}catch(_0x21e9e6){_0x1ced16(_0x29d5c5(0x99)+_0x21e9e6);}}),adams({'nomCom':_0x1d6e98(0xac),'categorie':_0x1d6e98(0xae)},async(_0x22f059,_0x461ec0,_0x1afc29)=>{const _0x5fc0ca=_0x1d6e98,{ms:_0xee7e60,repondre:_0x401ba9,arg:_0x9693b2}=_0x1afc29;if(!_0x9693b2[0x0]){_0x401ba9(_0x5fc0ca(0xa0));return;};try{let _0x352bc4=await fetch(_0x5fc0ca(0x78));_0x352bc4[_0x5fc0ca(0x8c)][_0x5fc0ca(0x8c)][_0x5fc0ca(0x8c)][0x0]['type']==_0x5fc0ca(0x93)?_0x461ec0[_0x5fc0ca(0x9c)](_0x22f059,{'video':{'url':_0x352bc4[_0x5fc0ca(0x8c)]['data'][_0x5fc0ca(0x8c)][0x0]['url_download']},'caption':_0x5fc0ca(0x98),'gifPlayback':![]},{'quoted':_0xee7e60}):_0x461ec0[_0x5fc0ca(0x9c)](_0x22f059,{'image':{'url':_0x352bc4[_0x5fc0ca(0x8c)][_0x5fc0ca(0x8c)][_0x5fc0ca(0x8c)][0x0][_0x5fc0ca(0x82)]},'caption':'Here\x20is\x20your\x20Instagram\x20image.\x0aPowered\x20by\x20*BMW-MD*'});}catch(_0x37cee8){_0x401ba9(_0x5fc0ca(0x69)+_0x37cee8);}}),adams({'nomCom':'video-dl','categorie':_0x1d6e98(0xae)},async(_0x4c1826,_0x4a0561,_0x44059d)=>{const _0x346bd9=_0x1d6e98,{ms:_0x4008b1,repondre:_0x1bfa04,arg:_0x2ccc17}=_0x44059d;let _0x53688d=_0x2ccc17[_0x346bd9(0x92)]('\x20');if(!_0x2ccc17[0x0]){_0x1bfa04(_0x346bd9(0x8f));return;}try{const _0x46927c=await fetch('https://www.noobs-api.000.pe/dipto/alldl?url='+_0x53688d),_0x139c10=await _0x46927c[_0x346bd9(0x6e)](),_0x2dbcc9=_0x139c10['result'];_0x4a0561[_0x346bd9(0x9c)](_0x4c1826,{'video':{'url':_0x2dbcc9},'caption':'_╰►VIDEO\x20DOWNLOADED\x20BY_\x20*BMW-MD*','gifPlayback':![]},{'quoted':_0x4008b1});}catch(_0x1154f4){_0x1bfa04(_0x346bd9(0x99)+_0x1154f4);}}),adams({'nomCom':_0x1d6e98(0x75),'categorie':_0x1d6e98(0xae)},async(_0x5b8e3d,_0x5540c4,_0x1e1c26)=>{const _0x30896a=_0x1d6e98,{ms:_0x48c053,repondre:_0x47575a,arg:_0x21e5ed}=_0x1e1c26;let _0x4adde6=_0x21e5ed[_0x30896a(0x92)]('\x20');if(!_0x21e5ed[0x0]){_0x47575a('Please\x20insert\x20a\x20*TWITTER\x20or\x20X\x20Video\x20Link*\x20for\x20*BMW-MD*\x20to\x20download\x20');return;}try{const _0x395757=await fetch(_0x30896a(0x81)+_0x4adde6),_0x5051a9=await _0x395757[_0x30896a(0x6e)]();if(_0x5051a9&&_0x5051a9['data']&&_0x5051a9[_0x30896a(0x8c)]['HD']){const _0x18124e=_0x5051a9[_0x30896a(0x8c)]['HD'];_0x5540c4[_0x30896a(0x9c)](_0x5b8e3d,{'video':{'url':_0x18124e},'caption':_0x30896a(0x85),'gifPlayback':![]},{'quoted':_0x48c053});}}catch(_0x3ef46){_0x47575a(_0x30896a(0x72)+_0x3ef46);}}),adams({'nomCom':_0x1d6e98(0x79),'categorie':_0x1d6e98(0xae)},async(_0x236640,_0x2eef16,_0x1194ad)=>{const _0x14ef5d=_0x1d6e98,{ms:_0x3ce23c,repondre:_0xbdf30c,arg:_0x594be1}=_0x1194ad;let _0x4625bd=_0x594be1[_0x14ef5d(0x92)]('\x20');if(!_0x594be1[0x0]){_0xbdf30c(_0x14ef5d(0x8b));return;};try{const _0x26e13c=await mediafireDl(_0x4625bd);if(_0x26e13c[0x0]['size'][_0x14ef5d(0x70)]('MB')[0x0]>=0x64)return m[_0x14ef5d(0x74)](_0x14ef5d(0x67));await _0x2eef16[_0x14ef5d(0x9c)](_0x236640,{'document':{'url':_0x26e13c[0x0][_0x14ef5d(0x9d)]},'fileName':_0x26e13c[0x0][_0x14ef5d(0x7a)],'mimetype':_0x26e13c[0x0][_0x14ef5d(0x7e)],'caption':_0x14ef5d(0x73)+_0x26e13c[0x0][_0x14ef5d(0x7a)]},{'quoted':_0x3ce23c});}catch(_0x32298d){_0xbdf30c(_0x14ef5d(0x7f)+_0x32298d);}}),adams({'nomCom':'fb','categorie':_0x1d6e98(0xae),'reaction':_0x1d6e98(0xa3)},async(_0x1a25c6,_0x1093b2,_0xdd563)=>{const _0x5f1dc6=_0x1d6e98,{repondre:_0x5560c9,ms:_0x3fd942,arg:_0x23f76c}=_0xdd563;if(!_0x23f76c[0x0]){_0x5560c9('Insert\x20a\x20public\x20facebook\x20video\x20link!');return;}const _0x210699=_0x23f76c[_0x5f1dc6(0x92)]('\x20');try{getFBInfo(_0x210699)[_0x5f1dc6(0x86)](_0x508db8=>{const _0x1eea69=_0x5f1dc6;let _0xe8c5f='\x0a\x20*Title:*\x20'+_0x508db8[_0x1eea69(0x6b)]+_0x1eea69(0x80)+_0x508db8[_0x1eea69(0xad)]+'\x0a\x20';_0x1093b2[_0x1eea69(0x9c)](_0x1a25c6,{'image':{'url':_0x508db8[_0x1eea69(0x95)]},'caption':_0xe8c5f},{'quoted':_0x3fd942}),_0x1093b2[_0x1eea69(0x9c)](_0x1a25c6,{'video':{'url':_0x508db8['hd']},'caption':_0x1eea69(0x7c)},{'quoted':_0x3fd942});})[_0x5f1dc6(0xa2)](_0x2d1226=>{const _0x524dfa=_0x5f1dc6;console[_0x524dfa(0x7b)](_0x524dfa(0xa9),_0x2d1226),_0x5560c9(_0x524dfa(0x6a));});}catch(_0xab1487){console[_0x5f1dc6(0xb1)](_0x5f1dc6(0x9e),_0xab1487),_0x5560c9('An\x20error\x20occurred\x20while\x20downloading\x20your\x20media.',_0xab1487);}}),adams({'nomCom':_0x1d6e98(0xb0),'categorie':'Download','reaction':_0x1d6e98(0xa3)},async(_0x7c724e,_0x49724a,_0x1edb91)=>{const _0x383628=_0x1d6e98,{repondre:_0x392003,ms:_0x536e9a,arg:_0x479e12}=_0x1edb91;if(!_0x479e12[0x0]){_0x392003(_0x383628(0x91));return;}const _0x439e43=_0x479e12['join']('\x20');try{getFBInfo(_0x439e43)[_0x383628(0x86)](_0x365ad0=>{const _0x1d79bf=_0x383628;let _0x3e059b=_0x1d79bf(0x83)+_0x365ad0[_0x1d79bf(0x6b)]+_0x1d79bf(0x80)+_0x365ad0[_0x1d79bf(0xad)]+'\x0a\x20';_0x49724a[_0x1d79bf(0x9c)](_0x7c724e,{'image':{'url':_0x365ad0[_0x1d79bf(0x95)]},'caption':_0x3e059b},{'quoted':_0x536e9a}),_0x49724a['sendMessage'](_0x7c724e,{'video':{'url':_0x365ad0['sd']},'caption':_0x1d79bf(0x7c)},{'quoted':_0x536e9a});})['catch'](_0x2623c6=>{const _0x52a265=_0x383628;console[_0x52a265(0x7b)](_0x52a265(0xa9),_0x2623c6),_0x392003(_0x2623c6);});}catch(_0x43dbf9){console[_0x383628(0xb1)](_0x383628(0x96),_0x43dbf9),_0x392003('An\x20error\x20occurred\x20while\x20Bmw-Md\x20was\x20downloading\x20your\x20media.',_0x43dbf9);}});function _0x153d(){const _0x296621=['Give\x20me\x20any\x20social\x20media\x20image\x20link!','provide\x20an\x20instragam\x20link\x20','Please\x20insert\x20a\x20tiktok\x20video\x20link!','catch','📽️','5980601uMvVYR','12RZrvCF','Please\x20provide\x20a\x20valid\x20github\x20link.','4OYNNmK','application/zip','Error:','../Ibrahim/dl/Function','HEAD','instagram','url','Download','100cXXYXg','fb2','error','_╰►IMAGE\x20DOWNLOADED\x20BY_\x20*BMW-MD*','File\x20tooooo\x20big','gitclone','An\x20error\x20Occurred\x20while\x20downloading\x20your\x20media.\x0a*KEEP\x20USING\x20BMW-MD*','try\x20fb2\x20on\x20this\x20link','title','4483660cgMOkD','8857014aRUpXw','json','replace','split','48FSKnpN','I\x20am\x20unable\x20to\x20download\x20your\x20media.\x20\x0a\x20','Downloaded\x20by\x20FLASH-MD:\x20','reply','twitter','image-dl','746403srBrud','https://www.guruapi.tech/api/igdlv1?url=${link}','mediafire','nama','log','_╰►VIDEO\x20DOWNLOADED\x20BY_\x20*BMW-MD*','result','mime','I\x20am\x20unable\x20to\x20download\x20the\x20file.\x20\x0a\x20','\x0a\x0a\x20\x0a\x20*Direct\x20Link:*\x20','https://api.maher-zubair.tech/download/twitter?url=','url_download','\x0a\x20*Title:*\x20','https://api.github.com/repos/','Here\x20is\x20your\x20Twitter\x20Video.\x0a\x20_Downloaded\x20by_\x20*BMW-MD*','then','no_wm','.zip','1970892oUPbXZ','https://api.prabath-md.tech/api/tiktokdl?url=','Provide\x20mediafire\x20link\x0a\x0amediafire\x20<valid\x20mediafire\x20link>','data','https://aiodownloader.onrender.com/download?url=','headers','Give\x20me\x20any\x20social\x20media\x20video\x20link!','36854QLKeDE','Insert\x20a\x20public\x20facebook\x20video\x20link!\x20!','join','video','content-disposition','thumbnail','An\x20error\x20occurred\x20while\x20Bmw-Md\x20was\x20downloading\x20your\x20media:','match','Here\x20is\x20your\x20Instagram\x20video.\x0aPowered\x20by\x20*BMW-MD*','A\x20fatal\x20error\x20has\x20occured...\x20\x0a\x20','Is\x20that\x20a\x20GitHub\x20repo\x20link\x20?!','4698573KGlmhD','sendMessage','link','An\x20error\x20occurred\x20while\x20*BMW-MD*\x20was\x20downloading\x20your\x20media:'];_0x153d=function(){return _0x296621;};return _0x153d();}



/**
const {
  mediafireDl
} = require("../Ibrahim/dl/Function");
const {
  adams
} = require("../Ibrahim/adams");
const getFBInfo = require("@xaviabot/fb-downloader");
adams({
  'nomCom': "gitclone",
  'categorie': "Download"
}, async (_0x1c2fd1, _0x45058e, _0x4f56d8) => {
  const {
    ms: _0x4ec678,
    repondre: _0x3f8a54,
    arg: _0x18d6ab
  } = _0x4f56d8;
  const _0x4bab3c = _0x18d6ab.join(" ");
  if (!_0x4bab3c) {
    return _0x3f8a54("Please provide a valid github link.");
  }
  if (!_0x4bab3c.includes("github.com")) {
    return _0x3f8a54("Is that a GitHub repo link ?!");
  }
  let [, _0x3acdad, _0x3f9933] = _0x4bab3c.match(/(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i) || [];
  _0x3f9933 = _0x3f9933.replace(/.git$/, '');
  let _0x394ebd = "https://api.github.com/repos/" + _0x3acdad + '/' + _0x3f9933 + "/zipball";
  let _0x5c6799 = (await fetch(_0x394ebd, {
    'method': "HEAD"
  })).headers.get("content-disposition").match(/attachment; filename=(.*)/)[1];
  _0x45058e.sendMessage(_0x1c2fd1, {
    'document': {
      'url': _0x394ebd
    },
    'fileName': _0x5c6799 + ".zip",
    'mimetype': "application/zip"
  }, {
    'quoted': _0x4ec678
  })["catch"](_0x2c3dbe => _0x3f8a54("error"));
});
adams({
  'nomCom': "tiktok",
  'categorie': "Download"
}, async (_0x42b1bf, _0x3a058d, _0x11f9d9) => {
  const {
    ms: _0x333a0e,
    repondre: _0x1a32e5,
    arg: _0x1b0b51
  } = _0x11f9d9;
  let _0x21bd31 = _0x1b0b51.join(" ");
  if (!_0x1b0b51[0]) {
    return _0x1a32e5("Please insert a tiktok video link!");
  }
  const _0x5d8397 = await fetch("https://api.prabath-md.tech/api/tiktokdl?url=" + _0x21bd31);
  const _0x38d5e1 = await _0x5d8397.json();
  await _0x1a32e5("A moment, *BMW-MD* is Downloading that...");
  const _0x504587 = _0x38d5e1.data.no_wm;
  await _0x3a058d.sendMessage(_0x42b1bf, {
    'video': {
      'url': _0x504587
    },
    'caption': "_╰►VIDEO DOWNLOADED BY_ *BMW-MD*",
    'gifPlayback': false
  }, {
    'quoted': _0x333a0e
  });
});
adams({
  'nomCom': "image-dl",
  'categorie': "Download"
}, async (_0x38d623, _0x42db7e, _0x1281b3) => {
  const {
    ms: _0x529878,
    repondre: _0x226795,
    arg: _0x2f8336
  } = _0x1281b3;
  let _0x3fc64a = _0x2f8336.join(" ");
  if (!_0x2f8336[0]) {
    _0x226795("Give me any social media image link!");
    return;
  }
  try {
    const _0x13451d = await fetch("https://aiodownloader.onrender.com/download?url=" + _0x3fc64a);
    const _0xb125b5 = await _0x13451d.json();
    const _0x9cb53 = _0xb125b5.result;
    _0x42db7e.sendMessage(_0x38d623, {
      'image': {
        'url': _0x9cb53
      },
      'caption': "_╰►IMAGE DOWNLOADED BY_ *BMW-MD*",
      'gifPlayback': false
    }, {
      'quoted': _0x529878
    });
  } catch (_0x53d9be) {
    _0x226795("A fatal error has occured... \n " + _0x53d9be);
  }
});
adams({
  'nomCom': "instagram",
  'categorie': "Download"
}, async (_0xf2a010, _0x3c01ae, _0x488f66) => {
  const {
    ms: _0x324321,
    repondre: _0x1eddf6,
    arg: _0x57528e
  } = _0x488f66;
  if (!_0x57528e[0]) {
    _0x1eddf6("provide an instragam link ");
    return;
  }
  ;
  try {
    let _0xfb5ca8 = await fetch("https://www.guruapi.tech/api/igdlv1?url=${link}");
    if (_0xfb5ca8.data.data.data[0].type == "video") {
      _0x3c01ae.sendMessage(_0xf2a010, {
        'video': {
          'url': _0xfb5ca8.data.data.data[0].url_download
        },
        'caption': "Here is your Instagram video.\nPowered by *BMW-MD*",
        'gifPlayback': false
      }, {
        'quoted': _0x324321
      });
    } else {
      _0x3c01ae.sendMessage(_0xf2a010, {
        'image': {
          'url': _0xfb5ca8.data.data.data[0].url_download
        },
        'caption': "Here is your Instagram image.\nPowered by *BMW-MD*"
      });
    }
  } catch (_0x4fdba6) {
    _0x1eddf6("An error Occurred while downloading your media.\n*KEEP USING BMW-MD*" + _0x4fdba6);
  }
});
adams({
  'nomCom': "video-dl",
  'categorie': "Download"
}, async (_0x46a8a0, _0x17b453, _0x2b60f2) => {
  const {
    ms: _0x589c36,
    repondre: _0x574033,
    arg: _0x23ec22
  } = _0x2b60f2;
  let _0x5e9106 = _0x23ec22.join(" ");
  if (!_0x23ec22[0]) {
    _0x574033("Give me any social media video link!");
    return;
  }
  try {
    const _0x22af05 = await fetch("https://www.noobs-api.000.pe/dipto/alldl?url=" + _0x5e9106);
    const _0x170f9e = await _0x22af05.json();
    const _0x3c3efe = _0x170f9e.result;
    _0x17b453.sendMessage(_0x46a8a0, {
      'video': {
        'url': _0x3c3efe
      },
      'caption': "_╰►VIDEO DOWNLOADED BY_ *BMW-MD*",
      'gifPlayback': false
    }, {
      'quoted': _0x589c36
    });
  } catch (_0x1cf0b8) {
    _0x574033("A fatal error has occured... \n " + _0x1cf0b8);
  }
});
adams({
  'nomCom': "twitter",
  'categorie': "Download"
}, async (_0x40d611, _0x29f4c2, _0x216827) => {
  const {
    ms: _0x178e4c,
    repondre: _0x330fea,
    arg: _0x1091be
  } = _0x216827;
  let _0x35e7e3 = _0x1091be.join(" ");
  if (!_0x1091be[0]) {
    _0x330fea("Please insert a *TWITTER or X Video Link* for *BMW-MD* to download ");
    return;
  }
  try {
    const _0x1e0844 = await fetch("https://api.maher-zubair.tech/download/twitter?url=" + _0x35e7e3);
    const _0x1e3a2f = await _0x1e0844.json();
    if (_0x1e3a2f && _0x1e3a2f.data && _0x1e3a2f.data.HD) {
      const _0x32bc4e = _0x1e3a2f.data.HD;
      _0x29f4c2.sendMessage(_0x40d611, {
        'video': {
          'url': _0x32bc4e
        },
        'caption': "Here is your Twitter Video.\n _Downloaded by_ *BMW-MD*",
        'gifPlayback': false
      }, {
        'quoted': _0x178e4c
      });
    }
  } catch (_0x19fce0) {
    _0x330fea("I am unable to download your media. \n " + _0x19fce0);
  }
});
adams({
  'nomCom': "mediafire",
  'categorie': "Download"
}, async (_0x12d48b, _0x1a75ba, _0x253e26) => {
  const {
    ms: _0x1cac40,
    repondre: _0x56acc0,
    arg: _0x4f5641
  } = _0x253e26;
  let _0x404891 = _0x4f5641.join(" ");
  if (!_0x4f5641[0]) {
    _0x56acc0("Provide mediafire link\n\nmediafire <valid mediafire link>");
    return;
  }
  ;
  try {
    const _0x5c499c = await mediafireDl(_0x404891);
    if (_0x5c499c[0].size.split('MB')[0] >= 100) {
      return m.reply("File tooooo big");
    }
    await _0x1a75ba.sendMessage(_0x12d48b, {
      'document': {
        'url': _0x5c499c[0].link
      },
      'fileName': _0x5c499c[0].nama,
      'mimetype': _0x5c499c[0].mime,
      'caption': "Downloaded by FLASH-MD: " + _0x5c499c[0].nama
    }, {
      'quoted': _0x1cac40
    });
  } catch (_0x572051) {
    _0x56acc0("I am unable to download the file. \n " + _0x572051);
  }
});
adams({
  'nomCom': 'fb',
  'categorie': "Download",
  'reaction': "📽️"
}, async (_0x3a78a5, _0xc18979, _0xf0a7a0) => {
  const {
    repondre: _0x3c875a,
    ms: _0x2e8d37,
    arg: _0xd0f2d0
  } = _0xf0a7a0;
  if (!_0xd0f2d0[0]) {
    _0x3c875a("Insert a public facebook video link!");
    return;
  }
  const _0x5938f0 = _0xd0f2d0.join(" ");
  try {
    getFBInfo(_0x5938f0).then(_0x44be8d => {
      let _0x76640a = "\n *Title:* " + _0x44be8d.title + "\n\n \n *Direct Link:* " + _0x44be8d.url + "\n ";
      _0xc18979.sendMessage(_0x3a78a5, {
        'image': {
          'url': _0x44be8d.thumbnail
        },
        'caption': _0x76640a
      }, {
        'quoted': _0x2e8d37
      });
      _0xc18979.sendMessage(_0x3a78a5, {
        'video': {
          'url': _0x44be8d.hd
        },
        'caption': "_╰►VIDEO DOWNLOADED BY_ *BMW-MD*"
      }, {
        'quoted': _0x2e8d37
      });
    })["catch"](_0x41d84f => {
      console.log("Error:", _0x41d84f);
      _0x3c875a("try fb2 on this link");
    });
  } catch (_0x1d71c9) {
    console.error("An error occurred while *BMW-MD* was downloading your media:", _0x1d71c9);
    _0x3c875a("An error occurred while downloading your media.", _0x1d71c9);
  }
});
adams({
  'nomCom': "fb2",
  'categorie': "Download",
  'reaction': "📽️"
}, async (_0xcad438, _0x341fa4, _0x1bf24c) => {
  const {
    repondre: _0x55e155,
    ms: _0x41f279,
    arg: _0x2b5eb7
  } = _0x1bf24c;
  if (!_0x2b5eb7[0]) {
    _0x55e155("Insert a public facebook video link! !");
    return;
  }
  const _0x1fd99e = _0x2b5eb7.join(" ");
  try {
    getFBInfo(_0x1fd99e).then(_0x2bbae1 => {
      let _0x8231c = "\n *Title:* " + _0x2bbae1.title + "\n\n \n *Direct Link:* " + _0x2bbae1.url + "\n ";
      _0x341fa4.sendMessage(_0xcad438, {
        'image': {
          'url': _0x2bbae1.thumbnail
        },
        'caption': _0x8231c
      }, {
        'quoted': _0x41f279
      });
      _0x341fa4.sendMessage(_0xcad438, {
        'video': {
          'url': _0x2bbae1.sd
        },
        'caption': "_╰►VIDEO DOWNLOADED BY_ *BMW-MD*"
      }, {
        'quoted': _0x41f279
      });
    })["catch"](_0x3eb21d => {
      console.log("Error:", _0x3eb21d);
      _0x55e155(_0x3eb21d);
    });
  } catch (_0x2b1e09) {
    console.error("An error occurred while Bmw-Md was downloading your media:", _0x2b1e09);
    _0x55e155("An error occurred while Bmw-Md was downloading your media.", _0x2b1e09);
  }
});


const {adams} = require('../Ibrahim/adams');
const fs = require('fs');
const getFBInfo = require("@xaviabot/fb-downloader");
const { default: axios } = require('axios');

adams({nomCom : "instagram" , categorie : "Download"},async (dest , zk , commandeOptions)=>{
  const {ms,repondre,arg} = commandeOptions ;

  let link = arg.join(' ')

  if (!arg[0]) { repondre('Veillez insérer un lien video instagramme');return}; 

  try {
     
    let igvid = await axios('https://vihangayt.me/download/instagram?url='+link)

    if (igvid.data.data.data[0].type == 'video') {
    zk.sendMessage(dest,{video : {url : igvid.data.data.data[0].url},caption : "ig video downloader powered by *Bmw-Md*",gifPlayback : false },{quoted : ms}) 
    }
    else {
        zk.sendMessage(dest,{image : {url : igvid.data.data.data[0].url},caption : "ig image downloader powered by *Bmw-Md*"})
    }
  
  } catch (e) {repondre("erreur survenue lors du téléchargement \n " + e)}
  
});


adams({
  nomCom: "facabook",
  categorie: "Download",
  reaction: "📽️"
},
async (dest, zk, commandeOptions) => {
  const { repondre, ms, arg } = commandeOptions;

  if (!arg[0]) {
    repondre('Insert a public facebook video link!');
    return;
  }

  const queryURL = arg.join(" ");

  try {
     getFBInfo(queryURL)
    .then((result) => {
       let caption = `
        titre: ${result.title}
        Lien: ${result.url}
      `;
       zk.sendMessage(dest,{image : { url : result.thumbnail}, caption : caption},{quoted : ms}) ;
       zk.sendMessage(dest, { video: { url: result.hd  }, caption: 'facebook video downloader powered by *Bmw-MD*' }, { quoted: ms });
      
    })
    .catch((error) => {console.log("Error:", error)
                      repondre('try fbdl2 on this link')});


   
  } catch (error) {
    console.error('Erreur lors du téléchargement de la vidéo :', error);
    repondre('Erreur lors du téléchargement de la vidéo.' , error);
  }
});



adams({ nomCom: "tiktok", categorie: "Download", reaction: "🎵" }, async (dest, zk, commandeOptions) => {
  const { arg, ms, prefixe,repondre } = commandeOptions;
  if (!arg[0]) {
    repondre(`how to use this command:\n ${prefixe}tiktok tiktok_video_link`);
    return;
  }

  const videoUrl = arg.join(" ");

 let data = await axios.get('https://vihangayt.me/download/tiktok?url='+ videoUrl) ;

  let tik = data.data.data

      // Envoi du message avec le thumbnail de la vidéo
      const caption = `
Author: ${tik.author}
Description: ${tik.desc}
      `;

         
      zk.sendMessage(dest, { video: { url: tik.links[0].a} , caption : caption },{quoted : ms});    

  
});

adams({
  nomCom: "facebook2",
  categorie: "Download",
  reaction: "📽️"
},
async (dest, zk, commandeOptions) => {
  const { repondre, ms, arg } = commandeOptions;

  if (!arg[0]) {
    repondre('Insert a public facebook video link! !');
    return;
  }

  const queryURL = arg.join(" ");

  try {
     getFBInfo(queryURL)
    .then((result) => {
       let caption = `
        titre: ${result.title}
        Lien: ${result.url}
      `;
       zk.sendMessage(dest,{image : { url : result.thumbnail}, caption : caption},{quoted : ms}) ;
       zk.sendMessage(dest, { video: { url: result.sd  }, caption: 'facebook video downloader powered by *Bmw-MD*' }, { quoted: ms });
      
    })
    .catch((error) => {console.log("Error:", error)
                      repondre(error)});


   
  } catch (error) {
    console.error('Erreur lors du téléchargement de la vidéo :', error);
    repondre('Erreur lors du téléchargement de la vidéo.' , error);
  }
});
**/
